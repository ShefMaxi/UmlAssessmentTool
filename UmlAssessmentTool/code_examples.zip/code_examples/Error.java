public class Error
{
    public static void main(String[] args)
    {
        double []x = new double[91209012];
        System.out.println("Hey, hey, hey!");
    }
}
