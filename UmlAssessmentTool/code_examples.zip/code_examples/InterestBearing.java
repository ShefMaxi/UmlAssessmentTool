public interface InterestBearing
{

    public abstract double getInterestRate();

}
