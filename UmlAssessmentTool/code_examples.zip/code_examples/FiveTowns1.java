import java.util.Random;

public class FiveTowns1
{

    public static void method1()
    {
        String[] fiveTowns = new String[5];
        fiveTowns[0] = "Tunstall";
        fiveTowns[1] = "Burslem";
        fiveTowns[2] = "Hanley";
        fiveTowns[3] = "Stoke";
        fiveTowns[4] = "Fenton";
        fiveTowns[5] = "Longton";
    }

    public static void main(String[] args)
    {

        method1();

        System.out.println("here\n");

    }
}
