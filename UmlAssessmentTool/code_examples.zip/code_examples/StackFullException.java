public class StackFullException extends Exception
{

    public StackFullException()
    {
        super();
    }
    public StackFullException(String desc)
    {
        super(desc);
    }
}
