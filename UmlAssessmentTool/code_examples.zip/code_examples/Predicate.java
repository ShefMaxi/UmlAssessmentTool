interface Predicate<T>
{
    boolean pred(T o);
}
