public interface MyStack<T>
{
    public void push(T obj);
    public T pop();
    public int size();
}
