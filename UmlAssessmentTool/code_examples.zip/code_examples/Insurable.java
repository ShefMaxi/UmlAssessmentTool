public interface Insurable
{

    public abstract double getPremium();

}
